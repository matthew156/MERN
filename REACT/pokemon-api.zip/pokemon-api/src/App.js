import './App.css';
import Pokemon from './components/pokemon';

function App() {
  return (
    <div className="App">
      <Pokemon></Pokemon>
    </div>
  );
}

export default App;
